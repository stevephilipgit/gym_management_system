# 05 — Authorization (RBAC + Gender Scope)

## Roles (from `models/Admin.js`)

```
role: enum ["superadmin", "trainer", "finance"], default "trainer"
scope: enum ["all", "male", "female_plus_transgender"], default "all"
```

Role and scope are separate dimensions:
- `role` gates **admin/module** operations (requireRole).
- `scope` gates **member/enquiry/attendance data** by gender.

Both are signed into the access JWT and restored by `adminAuth`
(`req.admin = { id, username, role, scope }`). Scope is **never re-read from
the DB on each request** — a scope change takes effect only at next login/refresh.

## Role matrix (verified against routes)

| Feature | superadmin | trainer | finance | Backend enforced? |
|---------|-----------|---------|---------|-------------------|
| Admin create/update/delete/list/reset | ✅ | ❌ | ❌ | ✅ `requireRole("superadmin")` (adminRoutes.js:43-58) |
| Package create/update/delete | ✅ | ❌ | ❌ | ✅ requireRole (packageRoutes.js:21-27) |
| Package read | ✅ | ✅ | ✅ | ✅ adminAuth |
| Dynamic field create/toggle/delete | ✅ | ❌ | ❌ | ✅ requireRole (fieldRoutes.js:21-27) |
| System settings read/write | ✅ | ❌ | ❌ | ✅ requireRole (systemSettingsRoutes.js:13-21) |
| AI chat/confirm | ✅ | ❌ | ❌ | ✅ requireRole at mount (server.js:155) |
| Google Sheets connectors | ✅ | ❌ | ❌ | ✅ requireRole (connectorsRoutes.js) |
| Enquiry delete | ✅ | ❌ | ❌ | ✅ requireRole("superadmin") (enquiryRoutes.js:45) |
| Member delete | ✅ | ❌ | ❌ | ✅ requireRole("superadmin") (memberRoutes.js:53) |
| Member register/list/get/update/renew | ✅ | ✅ | ✅ | ✅ adminAuth + gender scope |
| Dues list | ✅ | ✅ | ✅ | ✅ adminAuth |
| Attendance (search-punch, punch, punch-manual, history, logs, stats) | ✅ | ✅ | ✅ | ⚠️ adminAuth **only — no requireRole, and gender scope MISSING on search-punch/punch-manual/stats** |
| Reports (inactive, exports) | ✅ | ✅ | ✅ | ⚠️ adminAuth only; attendance/inactive CSV exports have NO gender scope |
| Enquiries read/status | ✅ | ✅ | ✅ | ⚠️ adminAuth; scope overridable by `?gender=` query param |
| Diets create/update/**delete** | ✅ | ✅ | ✅ | ⚠️ **DELETE has NO requireRole** — any role incl. trainer can delete a diet (dietRoutes.js:30) |
| Finance dashboard/metrics | ✅ | ✅ | ✅ | ✅ adminAuth (no gender scope — finance is revenue-wide) |
| Dashboard (home) | ✅ | ✅ | ✅ | ✅ adminAuth |

**Findings:**
1. **Diet DELETE is not role-gated** (`dietRoutes.js:30` only has `adminAuth`).
   Any trainer or finance admin can delete diets. Frontend sidebar shows Diet
   Manager to every role and the UI exposes the delete button
   (`AdminDietManager.jsx:61`).
2. **Attendance endpoints are not role-gated** and `search-punch`,
   `punch-manual`, `stats/today` have **no gender scope** (see
   [11-attendance.md](11-attendance.md)).
3. **`finance` role has `scope: "all"` by default** — a finance admin sees all
   genders' member data (same as superadmin at the data level, minus the
   module gates).

## Gender scope model (`core/scopeResolver.js`)

```
SCOPE_RULES = {
  all:                    () => true,
  male:                   (g) => g === "Male",
  female_plus_transgender:(g) => g === "Female" || g === "Transgender",
}
```

Applied at:
- Member module: register (memberController.js:54), getMemberById/getMemberByGymId
  (209/234), update (261), delete (300), renew (460), list filters (166-176,
  325-336, 354-365, 544-555).
- Enquiry module: list/export filters and per-record checks (enquiryController.js).
- Reports: inactive members (reportsController.js:19-30), export members
  (149-160). **NOT** applied to export/attendance or export/inactive.
- Attendance: `punch` (333), `history` (512), `logs` (583-597). **NOT** applied
  to `search-punch`, `punch-manual`, `stats/today`.

## Frontend vs backend enforcement

- Frontend `RoleGuard`/sidebar only hide routes (UX). Backend `requireRole` is
  the real gate for module-level restrictions.
- Frontend `RegisterForm.jsx:197-215` limits the gender dropdown by
  `admin.scope` — cosmetic; backend re-validates on register.
- **Frontend-only restrictions do not exist for gender data** — the backend
  does the filtering (for the paths where it is implemented).

## Privilege escalation / IDOR risks

1. **Enquiry gender-scope override** (`enquiryController.js:206, 376`): if a
   client sends `?gender=Female`, the scope filter is replaced by the client
   value. A male-scope trainer can read female enquiries. **HIGH.**
2. **Attendance search-punch / punch-manual** accept any member (by gymId or
   ObjectId) with no scope check. A male trainer can punch/read female and
   transgender members. **HIGH.**
3. **Attendance stats/today** returns global all-gender counts. **MEDIUM.**
4. **Reports export/attendance + export/inactive** return all genders. **MEDIUM.**
5. **Diet DELETE** unrestricted by role. **MEDIUM.**
6. **getAllMembers `?search=`** path bypasses the gender filter
   (`memberController.js:181` calls `memberRepository.search(search)` without
   the gender filter). **MEDIUM.**
7. `getInactiveMembers` total count omits the gender filter
   (`reportsController.js:56-62`) — count leakage (minor).
8. Admin `updateAdmin`/`deleteAdmin` routes are superadmin-gated; authController
   does not independently check that the target is not themselves — a superadmin
   can delete their own account (intended capability, no lockout guard).
