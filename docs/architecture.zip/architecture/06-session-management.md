# 06 — Session Management

## Model: stateless JWT + rotating refresh

There is **no server-side session store** (no Redis sessions, no Mongo session
collection). Sessions are entirely stateless JWT pairs carried in httpOnly
cookies.

```
Browser                          Express
  cookie gym_admin_token  ──────► adminAuth: jwt.verify(access)
  cookie gym_admin_refresh  ────► POST /admin/refresh → rotate → new pair
```

## What is stored where

| Data | Location |
|------|----------|
| Access JWT | httpOnly cookie `gym_admin_token`, path `/` |
| Refresh JWT | httpOnly cookie `gym_admin_refresh`, path `/api/admin` |
| Admin identity/role/scope | encoded inside the JWTs + persisted in `admins` collection |
| Audit trail | `auditlogs` collection (request logger) + Winston files |
| Admin sessions count | none tracked |

## Cookie details (verified, authController.js:57-72)

- `gym_admin_token`: httpOnly, secure in production, sameSite=strict, path `/`,
  maxAge = access expiry (default 15m).
- `gym_admin_refresh`: httpOnly, secure in production, sameSite=strict,
  path `/api/admin`, maxAge = refresh expiry (default 7d).
- No `__Host-` prefix, no explicit `domain`.

## Refresh / rotation behavior

`POST /api/admin/refresh` (authController.js:147):
1. Reads refresh cookie.
2. `jwt.verify` with refresh secret.
3. Loads admin by `decoded.id` (ensures the admin still exists).
4. Issues **both** a new access token and a new refresh token (rotates).
5. Resets cookies.

Frontend `apiClient.js`: on 401 from any request, performs a single-flight
`POST /admin/refresh`, queues concurrent requests, replays them after refresh.
On refresh failure, it clears redirect state to `/login`.

## Token invalidation / logout

- `POST /api/admin/logout` clears both cookies and audits the logout.
- **No server-side token blacklist/revocation.** A stolen access JWT remains
  usable until expiry (≤15m); a stolen refresh JWT remains usable until its
  7-day expiry because rotation only replaces the cookie, and the old refresh
  token is not recorded as used/denied.
- Change-password does not invalidate existing sessions.
- Reset-OTP and admin deletion do not invalidate issued tokens (the `adminAuth`
  middleware never checks the DB).

## Concurrent sessions

- Unlimited concurrent sessions (stateless). Admin A's session does not affect
  Admin B's.
- Admin A logout only clears A's cookies; B's cookies are untouched.

## Cross-admin data isolation

- Authorization is per-request based on the JWT claims (`req.admin.role`,
  `req.admin.scope`). One admin's browser cannot access another admin's
  workspace as long as the JWT is not shared.
- **BUT** the gender scope is trust-in-JWT: an attacker who can forge/modify the
  JWT (i.e., knows the access secret) can set `scope: "all"`. Secret
  management is the boundary.
- Admin A can only affect Admin B if A is a superadmin via the admin CRUD
  routes (which are superadmin-gated).

## Failure analysis

| Scenario | Behavior |
|----------|----------|
| Access token expired | 401 → frontend auto-refresh → new access token |
| Refresh token expired | refresh fails → redirect to /login |
| Refresh token invalid | 401 on refresh → cookies cleared → /login |
| Redis down | Rate limiters degrade to no-op; CAPTCHA unusable (login blocked); existing sessions keep working |
| Secret rotation | All tokens invalid → everyone re-logs in |
| Same-site cross-origin request | CORS blocks unless origin in ALLOWED_ORIGINS; cookies are SameSite=strict |

## Session isolation evidence

- `adminAuth.js` builds `req.admin` from the token only — it never loads the
  Admin document, so token claims are authoritative for the life of the token.
- `issueTokens` includes `role` and `scope` in the access token; a scope change
  in the DB takes effect only after re-login or refresh.
